# SIMPLE HANGMAN GAME IN PYTHON 3

## Requirements
- Python 3
- requirements.txt packages installed

## Instructions to Run
Install the required packages from the requirements.txt file with pip: `pip install -r requirements.txt`
Run with `python3 main.py`