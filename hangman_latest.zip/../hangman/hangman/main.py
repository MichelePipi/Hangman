from lib.hangman import Game


def run_hangman() -> None:
    Game()

if __name__ == '__main__':
    run_hangman()
